

ChatGPT:
ChatGPT
To execute your program with a lexer rule set and provide it with input (either from a .txt file or manually), here are the steps you need to follow:

1. Setup Your Environment
Make sure your project structure looks something like this:

bash
Code kopieren
/home/marvin/SpKo/aufgabe1/02-lexer/lexer/
├── ExprLexer.g4          # Your lexer grammar file
├── ExprLexer.java        # Generated lexer class from ANTLR
├── ExprTokenizer.java     # Your tokenizer class
└── input.txt             # (optional) Input file for testing
2. Generate Lexer from Grammar
If you haven't already generated the lexer from the .g4 file, you can do this using the ANTLR jar file:

bash
Code kopieren
java -cp /home/marvin/SpKo/aufgabe1/02-lexer/lexer/antlr-4.13.2-complete.jar org.antlr.v4.Tool ExprLexer.g4
This will create the ExprLexer.java file in your directory.

3. Compile the Lexer and Tokenizer
Compile the lexer and your tokenizer class:

bash
Code kopieren
javac -cp .:/home/marvin/SpKo/aufgabe1/02-lexer/lexer/antlr-4.13.2-complete.jar ExprLexer.java ExprTokenizer.java
4. Prepare Input
Manual Input:
You can run the ExprTokenizer and provide input manually:

bash
Code kopieren
java -cp .:/home/marvin/SpKo/aufgabe1/02-lexer/lexer/antlr-4.13.2-complete.jar ExprTokenizer
Then type your expression (like 3 + 4 * 2) and end it with Ctrl+D (Unix/Linux/Mac) or Ctrl+Z (Windows).